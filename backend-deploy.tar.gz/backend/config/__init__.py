# PostgreSQL configuration - no additional setup needed
