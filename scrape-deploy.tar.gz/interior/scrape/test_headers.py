import requests
from bs4 import BeautifulSoup

URL = "https://www.houzz.in/pro/gagandeep-kaur44/homez-designer"

# Different header configurations to test
HEADER_CONFIGS = {
    "1_minimal": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    },
    "2_full_chrome": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.houzz.in/",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Cache-Control": "max-age=0"
    },
    "3_chrome_with_cookies": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
    },
    "4_firefox": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.houzz.in/",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
    },
    "5_safari": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.houzz.in/",
        "Connection": "keep-alive"
    },
    "6_edge": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.houzz.in/",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
    },
    "7_session_based": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
}

def test_header_config(name, headers):
    """Test a header configuration"""
    print(f"\n{'='*60}")
    print(f"Testing: {name}")
    print(f"{'='*60}")
    
    try:
        # Try with session first
        session = requests.Session()
        session.headers.update(headers)
        
        # First request to get cookies
        response = session.get(URL, timeout=20, allow_redirects=True)
        
        print(f"Status Code: {response.status_code}")
        print(f"Final URL: {response.url[:100]}")
        print(f"Content Length: {len(response.text)}")
        
        # Check if we got an error page
        if "error" in response.url.lower() or response.status_code >= 500:
            print(f"❌ FAILED - Got error page or 500 status")
            return False
        
        # Try to parse and find expected content
        soup = BeautifulSoup(response.text, "html.parser")
        about_section = soup.find("section", id="about-us")
        projects_section = soup.find("section", id="projects")
        
        if about_section or projects_section:
            print(f"✅ SUCCESS - Found expected content!")
            print(f"   About section: {'Found' if about_section else 'Not found'}")
            print(f"   Projects section: {'Found' if projects_section else 'Not found'}")
            return True
        else:
            print(f"⚠️  Got 200 but no expected content found")
            # Show first 300 chars of response
            print(f"   First 300 chars: {response.text[:300]}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ ERROR: {str(e)}")
        return False
    except Exception as e:
        print(f"❌ UNEXPECTED ERROR: {str(e)}")
        return False

# Test all configurations
print("🧪 Testing different header configurations...")
print(f"Target URL: {URL}\n")

results = {}
for name, headers in HEADER_CONFIGS.items():
    results[name] = test_header_config(name, headers)

# Summary
print(f"\n{'='*60}")
print("SUMMARY")
print(f"{'='*60}")
for name, success in results.items():
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"{status}: {name}")

print(f"\n{'='*60}")
successful_configs = [name for name, success in results.items() if success]
if successful_configs:
    print(f"✅ Working configurations: {', '.join(successful_configs)}")
    print(f"\nRecommended headers to use:")
    print(HEADER_CONFIGS[successful_configs[0]])
else:
    print("❌ No working configuration found. This suggests:")
    print("   1. IP-based blocking (try different network/VPN)")
    print("   2. Geographic restrictions")
    print("   3. The site requires JavaScript rendering")
    print("   4. The site detects automated requests via other means")

