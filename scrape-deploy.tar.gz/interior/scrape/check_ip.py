#!/usr/bin/env python3
"""Check your IP and see if it's being blocked"""
import requests

print("Checking your IP address and location...")
print("="*60)

try:
    # Check IP info
    ip_resp = requests.get("https://api.ipify.org?format=json", timeout=10)
    ip_data = ip_resp.json()
    print(f"Your IP Address: {ip_data['ip']}")
    
    # Get more IP info
    try:
        ip_info = requests.get(f"http://ip-api.com/json/{ip_data['ip']}", timeout=10)
        info = ip_info.json()
        print(f"Country: {info.get('country', 'Unknown')}")
        print(f"Region: {info.get('regionName', 'Unknown')}")
        print(f"City: {info.get('city', 'Unknown')}")
        print(f"ISP: {info.get('isp', 'Unknown')}")
        print(f"Organization: {info.get('org', 'Unknown')}")
    except:
        pass
    
    print("\n" + "="*60)
    print("Testing connection to houzz.in...")
    
    # Test houzz.in connection
    test_resp = requests.get("https://www.houzz.in/", timeout=10, 
                            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    print(f"Status Code: {test_resp.status_code}")
    
    if test_resp.status_code == 200:
        print("✅ Can connect to houzz.in homepage")
    else:
        print(f"❌ Cannot connect to houzz.in (Status: {test_resp.status_code})")
        
except Exception as e:
    print(f"Error: {e}")

